# Ria's Creations Salon: website demo

A one-page website mock-up to show Ria (Lilburn, GA). No install needed.

**To open it:** double-click `index.html`. It opens in your web browser.
Fonts and the map need internet; everything else works offline.

## Add the lounge photo

Save the waiting-lounge photo (brown chairs, olive tree, lit oval mirror) as
`images/lounge.webp`. It appears next to the booking form. Every photo on the page is
used only once, so until that file exists the lounge card stays hidden.

## Files

| File | What |
|---|---|
| `index.html` | All content, already rendered (works before the script loads) |
| `styles.css` | Colors, type, layout, motion |
| `app.js` | Interactions (plain JS) |
| `vendor/anime.hero.min.js` | Anime.js v4.5.0 (MIT), a slim build used only for the hero intro. If it fails to load, a CSS version of the intro plays instead |
| `images/` | One photo per spot |
| `privacy.html`, `terms.html` | Plain-language drafts for Ria to review |
| `tests/audit.cjs` | The design audit; results in `AUDIT.md` |

## Things to try

- Open the page fresh: it counts to 100% with her salon in the arched doorway, then walks you inside.
  It plays once per visit (close the tab to see it again); links like `index.html#book` skip it.

- Hover **Services** in the top bar. Move diagonally into the list; the category won't flip on the way (safe triangle).
- Press **Ctrl K** (or **⌘K**, or **/**) for the search menu. **T** switches day/evening. **B** jumps to booking.
- Click a photo. It grows into a viewer; drag it up or down to close.
- On a phone, the menu button opens a sheet you can swipe down to close.
- Book a visit: the button previews your request, "Request sent" shows instantly,
  then a 6-digit code box appears (any 6 digits work in the demo). **Cancel request** gives you 5 seconds to undo.

## Things to confirm with Ria

- The remaining prices (real so far: keratin from $150, eyebrow tint or wax $20, lashes from $40, Brazilian $35, full-body wax $65)
- The privacy and terms drafts
- Whether booking requests should text her phone
- Her logo file, to replace the matched script wordmark

Booking, the text code and the rating refresh are simulated in this demo. A real site
would send them to a small server (for example, SMS through a texting service and the
rating from Google).
